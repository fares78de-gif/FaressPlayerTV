# Fares Player TV — IB Player inspired interface

A native Android IPTV player project with an original dark/gold visual identity inspired by common IPTV player layouts.

## Current features
- Xtream Codes account login and saved accounts
- Live TV categories and channel list
- Portrait layout for Android phones
- Landscape three-column layout for Android TV / TV boxes (categories, channels, preview player)
- In-app live preview and full-screen playback
- Search, favorites, hide/show channels (no PIN)
- Remote-control / D-pad friendly focusable controls

## Build
Open this project in Android Studio, or build with Gradle 8.7 and JDK 17:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/`

The app is a media player only. It does not include channels or playlists; add an account from a provider you are authorized to use.

## Notes
This project has not been compiled or tested on a physical phone or Android TV in this environment. Verify the build and playback with your own authorized Xtream account before distribution.
